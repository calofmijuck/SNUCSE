//Student   Name:
//Student Number:
//Do not import any java libraries
//Do not write extra classes
public class Final3 {
    public Node root;
    //Do not create any field varable
    public Final3(String s) {
        //handle case s = "" and passing root to report(FinalNode n)
        //Modify as you wish
    }
    private void decode() {
        //Modify return type and parameter as you wish to build tree recursively
        //Modify as you wish
    }
    public Node getRoot() {
        return root;
    }
    public String encode(Node otherTreeRoot) { //you may change parameter name
        String s = "output the label of the node";
        s += " - encode the left subtree";
        s += " - encode the right subtree";
        s += "- output label of the node again.";
        //Modify as you wish
        return  s;
    }
    //Do not write any other method than provided
}