//Do NOT modify
//No need to submit this file
public class Node {
	public char label;
	public Node left;
	public Node right;
}