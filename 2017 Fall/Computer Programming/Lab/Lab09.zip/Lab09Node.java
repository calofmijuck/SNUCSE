public class Lab09Node {
	public Lab09Node left;
	public Lab09Node right;
	public int val;
	public Lab09Node(int v) {
		val = v;
	}
}