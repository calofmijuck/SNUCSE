public class Lab09Tree {
	private Lab09Node root;

	public void insert(int v) {
	}
	private void insert(int v, Lab09Node n) {
	}

	public String preorder() {
		return preorder(root);
	}

	public String inorder() {
		return inorder(root);
	}

	public String postorder() {
		return postorder(root);	
	}
	
	public String levelorder() {
	}
	
	public String preorder(Lab09Node n) {
	}

	public String inorder(Lab09Node n) {
	}

	public String postorder(Lab09Node n) {
	}

	public String levelorderR() {
	}
}